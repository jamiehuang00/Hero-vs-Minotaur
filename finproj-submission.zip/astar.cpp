#include "astar.h"
#include "game.h"
#include "entity.h"
#include "position.h"
#include "tile.h"

Astar::Astar(Entity *entity){
  start = entity->getPosition();
  target = h;
  goal = target->getPosition();
  g = 0;
  h = 0;
  
}

Astar::~AStar(){
}

bool Astar::isWall(Entity *entity){
  string block = entity::getGlyph();
  if (block == "#")
    return true;
  else
    return false;
}
void Astar::algorithm(){
  int m_x = start.getX();
  int m_y = start.getY();
  int h_x = orig_hero.getX();
  int h_y = orig_hero.getY();
  const Tile *tile;
  tile = game->getMaze()->getTile(epos.displace(hdir));
  
}

void Astar::solve(){
  Maze *maze;
  
  int max_x = maze.getWidth();
  int max_y = maze.getHeight();
  for (int x = 0; x < max_x; x++)
    for (int y = 0; y < max_y; y++){
      
    }
}

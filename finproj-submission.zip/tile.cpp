#include "tile.h"

Tile::Tile() {
}

Tile::~Tile() {
}

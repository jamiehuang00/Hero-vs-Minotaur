#include "entitycontroller.h"

EntityController::EntityController() {
}

EntityController::~EntityController() {
}

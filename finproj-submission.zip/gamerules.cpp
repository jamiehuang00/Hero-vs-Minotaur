#include "gamerules.h"

GameRules::GameRules() {
}

GameRules::~GameRules() {
}
